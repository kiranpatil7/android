package com.example.communicationwithjavaserver;

import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.communicationwithjavaserver.AsyncTasks.ExecuteTask;
import com.example.communicationwithjavaserver.AsyncTasks.Logout;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private Button btnSend;
    private EditText editTextData;
    public TextView textViewInfo;
    private String DEVICE_ID;
    private String Fname ="Kiran";
    private String Lname ="Patil";
    private String Email ="kpandsatish@gmail.com";
    private String Phone = "9923984601";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DEVICE_ID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        btnSend = findViewById(R.id.btnSend);
        editTextData = findViewById(R.id.editTextData);
        textViewInfo = findViewById(R.id.textViewInfo);
        textViewInfo.setText(DEVICE_ID);

        btnSend.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("DeviceId",DEVICE_ID);
                    jsonObject.put("FirstName",Fname);
                    jsonObject.put("LastName",Lname);
                    jsonObject.put("Email",Email);
                    jsonObject.put("Phone",Phone);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ExecuteTask executeTask = new ExecuteTask(jsonObject,new OnTaskCompleted() {
                    @Override
                    public void onTaskCompleted(String resp) {
                        JSONObject obj;
                        try{
                            obj = new JSONObject(resp);
                            Log.d("json",obj.get("DEVICE_ID").toString());
                            textViewInfo.setText(obj.get("uName").toString());
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });
                executeTask.execute(editTextData.getText().toString());
                Toast.makeText(getApplicationContext(), "Data Sent", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Logout logout = new Logout(DEVICE_ID, new OnTaskCompleted() {
            @Override
            public void onTaskCompleted(String response) {
                Log.d("logout",response);
                Toast.makeText(getApplicationContext(), "Destroyed", Toast.LENGTH_LONG).show();
            }
        });
        logout.execute();
    }
}