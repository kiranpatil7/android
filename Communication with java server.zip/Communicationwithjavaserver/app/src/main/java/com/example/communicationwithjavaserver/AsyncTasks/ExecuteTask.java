package com.example.communicationwithjavaserver.AsyncTasks;

import android.os.AsyncTask;
import android.util.Log;

import com.example.communicationwithjavaserver.OnTaskCompleted;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ExecuteTask extends AsyncTask<String,Integer,Response> {
    private String resp;
    private OnTaskCompleted listener;
  //  String DEVICE_ID;
    JSONObject jsonObject;
    MediaType MEDIA_TYPE = MediaType.parse("application/json");


    public ExecuteTask(JSONObject jsondata ,OnTaskCompleted listener){
        this.listener=listener;
        this.jsonObject=jsondata;
    }

    @Override
    protected Response doInBackground(String... params) {
        try {
            OkHttpClient client = new OkHttpClient();
            RequestBody formBody = RequestBody.create(MEDIA_TYPE, jsonObject.toString());

//            RequestBody formBody = new FormBody.Builder()
//                    .add("header", DEVICE_ID)
//                    .add("function","DataFetch")
//                    .add("uname", "Kiran")
//                    .add("upass", "Kiran")
//                    .build();
//            Request request = new Request.Builder().url("http://192.168.43.14:80/TrialApi/ApiHandler.php").method("POST", formBody) .header("Accept", "application/json")
//                    .header("Content-Type", "application/json").build();
            Request request = new Request.Builder().url("http://192.168.43.14:80/TrialApi/Init/Register.php").post(formBody).header("Accept", "application/json")
                    .header("Content-Type", "application/json").build();

            Response response = client.newCall(request).execute();


            return response;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Response response) {

        try {
            resp = response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d("Message",resp);

        listener.onTaskCompleted(resp);
    }


}
