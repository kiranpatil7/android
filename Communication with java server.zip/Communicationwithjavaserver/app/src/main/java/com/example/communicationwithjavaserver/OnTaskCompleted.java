package com.example.communicationwithjavaserver;

public interface OnTaskCompleted {
    void onTaskCompleted(String response);
}
