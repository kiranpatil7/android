package com.example.communicationwithjavaserver.AsyncTasks;

import android.os.AsyncTask;

import com.example.communicationwithjavaserver.OnTaskCompleted;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Logout extends AsyncTask<Void, Void, Response> {

    String DEVICE_ID;
    private OnTaskCompleted listener;

    public Logout(String DID, OnTaskCompleted listener ){
        this.DEVICE_ID=DID;
        this.listener = listener;
    }

    @Override
    protected Response doInBackground(Void...Void) {
        try {
            OkHttpClient client = new OkHttpClient();
            RequestBody formBody = new FormBody.Builder()
                    .add("header", DEVICE_ID)
                    .add("function","Logout")
                    .build();
            Request request = new Request.Builder().url("http://192.168.43.14:80/TrialApi/ApiHandler.php").method("POST", formBody).build();
            Response response = client.newCall(request).execute();
            return response;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Response response) {
        super.onPostExecute(response);

        try {
            listener.onTaskCompleted(response.body().string());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
