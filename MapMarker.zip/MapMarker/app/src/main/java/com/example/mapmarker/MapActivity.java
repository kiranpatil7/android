package com.example.mapmarker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.mapmarker.Plugine.GradientPolylinePlugin;
import com.google.android.gms.tasks.Task;
import com.mapbox.android.core.location.LocationEngine;
import com.mapbox.android.core.location.LocationEngineListener;
import com.mapbox.core.constants.Constants;
import com.mapbox.geojson.Point;
import com.mapbox.geojson.utils.PolylineUtils;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.annotations.Polyline;
import com.mapbox.mapboxsdk.annotations.PolylineOptions;
import com.mapbox.mapboxsdk.camera.CameraPosition;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.geometry.LatLngBounds;
import com.mapbox.mapboxsdk.location.LocationComponent;
import com.mapbox.mapboxsdk.location.LocationComponentOptions;
import com.mapbox.mapboxsdk.location.OnCameraTrackingChangedListener;
import com.mapbox.mapboxsdk.location.modes.CameraMode;
import com.mapbox.mapboxsdk.location.modes.RenderMode;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mmi.services.api.directions.DirectionsCriteria;
import com.mmi.services.api.directions.MapmyIndiaDirections;
import com.mmi.services.api.directions.models.DirectionsResponse;
import com.mmi.services.api.directions.models.DirectionsRoute;
import com.mmi.services.api.geocoding.GeoCode;
import com.mmi.services.api.geocoding.GeoCodeResponse;
import com.mmi.services.api.geocoding.MapmyIndiaGeoCoding;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback, LocationEngineListener {
    LocationComponent locationComponent;
    private MapboxMap mapmyIndiaMap;
     private GradientPolylinePlugin directionPolylinePlugin;
    private LinearLayout directionDetailsLayout;
    LocationEngine locationEngine;
    private Location location1;
    private Button addPolygonButton;
    private TextView tvDistance, tvDuration;
    private Context context = MapActivity.this;
     private String profile = DirectionsCriteria.PROFILE_BIKING;

    private ArrayList<LatLng> listOfLatlang = new ArrayList<>();
    //  private ArrayList<LatLng>list =new ArrayList<>();
    private Polyline polyline;
    MapView mapView;

    double startlong, startlat;
    double destinationlat, destinationlong;   //  private  Location location;
    String searchText = "Kolhapur";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        mapView = findViewById(R.id.map);
        addPolygonButton = findViewById(R.id.btn_add_polyline);
         directionDetailsLayout = findViewById(R.id.direction_details_layout);
        mapView.onCreate(savedInstanceState);
        tvDistance = findViewById(R.id.tv_distance);
        tvDuration = findViewById(R.id.tv_duration);
        mapView.getMapAsync(this);

        //  startActivity(new Intent(MapActivity.this,polyline.class));


    }

    @Override
    public void onConnected() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationEngine.requestLocationUpdates();
    }

    @Override
    public void onLocationChanged(Location location) {
        location1 = location;

       mapmyIndiaMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 16));

    }



    @Override
    protected void onResume() {
        super.onResume();
        if (locationEngine != null) {
            locationEngine.removeLocationEngineListener(this);
            locationEngine.addLocationEngineListener(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (locationEngine != null)
            locationEngine.removeLocationEngineListener(this);
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (locationEngine != null) {
            locationEngine.removeLocationEngineListener(this);
            locationEngine.removeLocationUpdates();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (locationEngine != null) {
            locationEngine.deactivate();
        }
    }

    private void enableLocation() {
        mapmyIndiaMap.setPadding(20, 20, 20, 20);
//        mapmyIndiaMap.setCameraPosition(setCameraAndTilt());
//        listOfLatlang.add(new LatLng(28.705436, 77.100462));
//        listOfLatlang.add(new LatLng(28.705191, 77.100784));
//        listOfLatlang.add(new LatLng(28.704646, 77.101514));
//        listOfLatlang.add(new LatLng(28.704194, 77.101171));
//        listOfLatlang.add(new LatLng(28.704083, 77.101066));
//        listOfLatlang.add(new LatLng(28.703900, 77.101318));

        /* this is done for animating/moving camera to particular position */

//        LatLngBounds latLngBounds = new LatLngBounds.Builder().includes(listOfLatlang).build();
//        mapmyIndiaMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 70));

        LocationComponentOptions options = LocationComponentOptions.builder(context)
                .trackingGesturesManagement(true)
                .accuracyColor(ContextCompat.getColor(context, R.color.colorAccent))
                .build();

// Get an instance of the component LocationComponent
        locationComponent = mapmyIndiaMap.getLocationComponent();
// Activate with options

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        locationComponent.activateLocationComponent(context, options);
// Enable to make component visiblelocationEngine
        locationComponent.setLocationComponentEnabled(true);
        locationEngine = locationComponent.getLocationEngine();

        locationEngine.addLocationEngineListener((LocationEngineListener) context);
// Set the component's camera mode
        locationComponent.setCameraMode(CameraMode.TRACKING);
        locationComponent.setRenderMode(RenderMode.GPS);
        addPolygonButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                startlat =location1.getLatitude();
//                startlong =location1.getLongitude();
                startlat =16.678085;
                startlong=74.257346;

                String s = startlat+" "+startlong;
                String s1 =destinationlat+ " "+destinationlong;
//                Log.d("Start",s);
//                Log.d("Destination",s1);
                MapmyIndiaDirections.builder()
                        .origin(Point.fromLngLat(startlong,startlat))
                        .steps(true)
                        .resource(DirectionsCriteria.RESOURCE_ROUTE_ETA)
                        .profile(DirectionsCriteria.PROFILE_BIKING)
                        .overview(DirectionsCriteria.OVERVIEW_FULL)
                        .destination(Point.fromLngLat(destinationlong,destinationlat))
                        .alternatives(true)
                        .build()
                        .enqueueCall(new Callback<DirectionsResponse>() {
                            @Override
                            public void onResponse(Call<DirectionsResponse> call, Response<DirectionsResponse> response) {
                                String s =response.body().toJson();
                              //  Log.d("Info",s);
                                if(response.code() ==200)
                                {
                                    if(response.body()!=null)
                                    {
                                        DirectionsResponse directionsResponse = response.body();
                                        List<DirectionsRoute> results = directionsResponse.routes();
                                        if(results.size()>0)
                                        {
                                            mapmyIndiaMap.clear();
                                            int count =0;
                                            Log.d("size",results.size()+"");
//                                            for(DirectionsRoute dir :results)
//                                            {
                                                DirectionsRoute directionsRoute = results.get(0);
                                            if (directionsRoute != null && directionsRoute.geometry() != null) {
                                                drawPath(PolylineUtils.decode(directionsRoute.geometry(), Constants.PRECISION_6));
                                                updateData(directionsRoute);

                                            }
                                            DirectionsRoute directionsRoute1 = results.get(1);
                                            if (directionsRoute1 != null && directionsRoute1.geometry() != null) {
                                                drawPath(PolylineUtils.decode(directionsRoute1.geometry(), Constants.PRECISION_6));
                                                updateData(directionsRoute1);

                                            }

                                            DirectionsRoute directionsRoute2 = results.get(2);
                                            if (directionsRoute2 != null && directionsRoute2.geometry() != null) {
                                                drawPath(PolylineUtils.decode(directionsRoute2.geometry(), Constants.PRECISION_6));
                                                updateData(directionsRoute2);

                                            }

                                            //  Log.d("Direcetion",dir.toJson());
//                                                count++;
//
//                                                if (directionsRoute != null && directionsRoute.geometry() != null) {
//                                                    drawPath(PolylineUtils.decode(directionsRoute.geometry(), Constants.PRECISION_6));
//                                                    updateData(directionsRoute);
//
//                                                }
////                                            }
//                                            Log.d("Count",count+"");



                                        }
                                    }

                                }
                                else
                                {
                                    Toast.makeText(context, response.message() + response.code(), Toast.LENGTH_LONG).show();

                                }



                            }

                            @Override
                            public void onFailure(Call<DirectionsResponse> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
//                listOfLatlang.add(new LatLng(startlat,startlong));
//                listOfLatlang.add(new LatLng(destinationlat,destinationlong));
//
//                LatLngBounds latLngBounds = new LatLngBounds.Builder().includes(listOfLatlang).build();
//                mapmyIndiaMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 70));
//                polyline = mapmyIndiaMap.addPolyline(new PolylineOptions().addAll(listOfLatlang).color(Color.parseColor("#3bb2d0")).width(4));
//                locationComponent.addOnCameraTrackingChangedListener(new OnCameraTrackingChangedListener() {
//                    @Override
//                    public void onCameraTrackingDismissed() {
//
//                    }
//
//                    @Override
//                    public void onCameraTrackingChanged(int i) {
//                        if(i!=0)
//                        {
//
////
//
//
//                            //mapmyIndiaMap.addPolyline(new PolylineOptions().addAll());
//                        }
//
//                    }
//                });





            }
        });


//
//        LatLngBounds latLngBounds = new LatLngBounds.Builder().includes(listOfLatlang).build();
//        mapmyIndiaMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 70));
//        polyline = mapmyIndiaMap.addPolyline(new PolylineOptions().addAll(listOfLatlang).color(Color.parseColor("#3bb2d0")).width(4));
//        locationComponent.addOnCameraTrackingChangedListener(new OnCameraTrackingChangedListener() {
//            @Override
//            public void onCameraTrackingDismissed() {
//
//            }
//
//            @Override
//            public void onCameraTrackingChanged(int i) {
//                if(i!=0)
//                {
//
////
//
//
//                    //mapmyIndiaMap.addPolyline(new PolylineOptions().addAll());
//                }
//
//            }
//        });



        //location = locationEngine.getLastLocation();

    }
    private void updateData(@NonNull DirectionsRoute directionsRoute) {
        if (directionsRoute.distance() != null && directionsRoute.distance() != null) {
            directionDetailsLayout.setVisibility(View.VISIBLE);
            tvDuration.setText("(" + getFormattedDuration(directionsRoute.duration()) + ")");
            tvDistance.setText(getFormattedDistance(directionsRoute.distance()));
        }
    }
    private String getFormattedDistance(double distance) {

        if ((distance / 1000) < 1) {
            return distance + "mtr.";
        }
        DecimalFormat decimalFormat = new DecimalFormat("#.#");
        return decimalFormat.format(distance / 1000) + "Km.";
    }
    private String getFormattedDuration(double duration) {
        long min = (long) (duration % 3600 / 60);
        long hours = (long) (duration % 86400 / 3600);
        long days = (long) (duration / 86400);
        if (days > 0L) {
            return days + " " + (days > 1L ? "Days" : "Day") + " " + hours + " " + "hr" + (min > 0L ? " " + min + " " + "min." : "");
        } else {
            return hours > 0L ? hours + " " + "hr" + (min > 0L ? " " + min + " " + "min" : "") : min + " " + "min.";
        }
    }
    private void drawPath(@NonNull List<Point> waypoints) {
        ArrayList<LatLng> listOfLatLng = new ArrayList<>();
        for (Point point : waypoints) {
            listOfLatLng.add(new LatLng(point.latitude(), point.longitude()));
        }

        if(directionPolylinePlugin == null) {
            directionPolylinePlugin = new GradientPolylinePlugin(mapmyIndiaMap, mapView, profile);
            directionPolylinePlugin.createPolyline(listOfLatLng);
        } else {
            directionPolylinePlugin.updatePolyline(profile, listOfLatLng);

        }
       // listOfLatLng.add();
      //  mapmyIndiaMap.addPolyline(new PolylineOptions().addAll(listOfLatLng).color(Color.parseColor("#3bb2d0")).width(4));
        LatLngBounds latLngBounds = new LatLngBounds.Builder().includes(listOfLatLng).build();
        mapmyIndiaMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, 30));
    }

//    private CameraPosition setCameraAndTilt() {
//        CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(
//                startlat, startlong)).zoom(14).tilt(0).build();
//
//        return cameraPosition;
//    }


    @Override
    public void onMapReady(final MapboxMap mapboxMap) {
        this.mapmyIndiaMap=mapboxMap;
        destination();
        enableLocation();





    }

    private void destination() {

        MapmyIndiaGeoCoding.builder()
                .setAddress(searchText)
                .build().enqueueCall(new Callback<GeoCodeResponse>() {
            @Override
            public void onResponse(Call<GeoCodeResponse> call, Response<GeoCodeResponse> response) {
                if (response.code() == 200) {
                    if (response.body() != null) {
                        List<GeoCode> placesList = response.body().getResults();
                        GeoCode place = placesList.get(0);
                        String add = "Latitude: " + place.latitude + " longitude: " + place.longitude;
                        addMarker(place.latitude, place.longitude);
                        destinationlat =place.latitude;
                        destinationlong =place.longitude;
                       // Toast.makeText(context, add, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Not able to get value, Try again.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
               // progressDialogHide();
            }

            @Override
            public void onFailure(Call<GeoCodeResponse> call, Throwable t) {
                Toast.makeText(context, t.toString(), Toast.LENGTH_SHORT).show();
                //progressDialogHide();
            }
        });
    }

    private void addMarker(double latitude, double longitude) {
        mapmyIndiaMap.addMarker(new MarkerOptions().position(new LatLng(
                latitude, longitude)));
    }

    @Override
    public void onMapError(int i, String s) {

    }
}