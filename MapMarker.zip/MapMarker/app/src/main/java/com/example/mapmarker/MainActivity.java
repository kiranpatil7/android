package com.example.mapmarker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.mapbox.android.core.location.LocationEngine;
import com.mapbox.android.core.location.LocationEngineListener;
import com.mapbox.mapboxsdk.MapmyIndia;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.location.LocationComponent;
import com.mapbox.mapboxsdk.location.LocationComponentOptions;
import com.mapbox.mapboxsdk.location.modes.CameraMode;
import com.mapbox.mapboxsdk.location.modes.RenderMode;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mmi.services.account.MapmyIndiaAccountManager;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MapmyIndiaAccountManager.getInstance().setRestAPIKey(getRestAPIKey());
        MapmyIndiaAccountManager.getInstance().setMapSDKKey(getMapSDKKey());
        MapmyIndiaAccountManager.getInstance().setAtlasClientId(getAtlasClientId());
        MapmyIndiaAccountManager.getInstance().setAtlasClientSecret(getAtlasClientSecret());
        MapmyIndiaAccountManager.getInstance().setAtlasGrantType(getAtlasGrantType());
        MapmyIndia.getInstance(MainActivity.this);

        startActivity(new Intent(MainActivity.this,MapActivity.class));


    }


    public String getAtlasClientId() {
        return "U549QW-s8axZM7R_kvngffRjlSKOFnIPvoPGAAtXo6w_sBBmXqXyhH7lQJR38aeO5tqx6l5jttMcmuyQnFV7JY0ZHHpoMOWpzeEaplPNdnCC0Njshkc1MQ==";
    }

    public String getAtlasClientSecret() {
        return "lrFxI-iSEg8y0caF6lGokymmQRzKaFqmxVzzc2Il6GpxYS0mpCMXn_s39NYh4_Vnv6M5L41Am8-gSHTE1zFypP738UP4o01wPfQoRRIoprshr4hGHFKkUTRLepsRLcTq";
    }


    public String getAtlasGrantType() {
        return "client_credentials";
    }

    public String getMapSDKKey() {
        return "gd6bredy71lrn442wtmrp1365sreuota";
    }

    public String getRestAPIKey() {
        return "t1sqvf93vhcnln71etqljk3ygrqma3l3";
    }

}